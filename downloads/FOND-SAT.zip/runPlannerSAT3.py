#!/usr/bin/python
import sys
import os
import subprocess

def main() :
	domains = ["data/benchmarks-fond_sat/acrobatics/",
			   "data/benchmarks-fond_sat/beam-walk/",
			   "data/benchmarks-fond_sat/blocksworld-ipc08/",
			   "data/benchmarks-fond_sat/door/",
			   "data/benchmarks-fond_sat/earth_observation/",
			   "data/benchmarks-fond_sat/elevators/",
			   "data/benchmarks-fond_sat/first-responders-ipc08/",
			   "data/benchmarks-fond_sat/miner/",
			   "data/benchmarks-fond_sat/tireworld/",
			   "data/benchmarks-fond_sat/tireworld-truck/",
			   "data/benchmarks-fond_sat/triangle-tireworld/",
			   "data/benchmarks-fond_sat/spiky-tireworld/",
			   "data/benchmarks-fond_sat/zenotravel/"
			   ]

	heuristics = ["FF", "HMAX", "LMCUT", "PDBS", "ZERO"]

	strategies = [
				  '"[MIN_H(FF), MIN_DEPTH]"',
				  '"[MIN_H(HMAX), MIN_DEPTH]"',
				  '"[MIN_H(LMCUT), MIN_DEPTH]"',
				  '"[MIN_H(PDBS), MIN_DEPTH]"',
				  '"[MIN_H(ZERO), MIN_DEPTH]"'
				  ]

	searches = ["LAOSTAR"]

	for domain in domains:
		for filename in os.listdir(domain):
			for search in searches:
				for h in heuristics:
					for s in strategies:
						if h in s:
							continue
					
						for filename in os.listdir(domain):
							if ".pddl" in filename and 'domain.pddl' not in filename:
								pddl_p = filename.split('/')
								pddl_p = pddl_p[len(pddl_p)-1]
								domain_n = domain.split('/')
								domain_n = domain_n[len(domain_n)-2]
								output_file =  domain_n + '-' + pddl_p.replace('.pddl', '') + '-' + search + '-' + h + '-' + s + '.txt'
								command = 'java -jar myNDPlus0.1.jar -timeout 1200 -search ' + search + ' -heuristic ' + h + ' -strategy ' + s + ' -t FOND ' + domain + 'domain.pddl ' + domain + filename + ' > ' + output_file
								print command
								print ''
								os.system(command)

if __name__ == '__main__' :
	main()
