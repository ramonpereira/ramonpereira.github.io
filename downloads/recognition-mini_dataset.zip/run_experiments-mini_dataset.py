#!/usr/bin/python
import sys
import os
import math

def main() :
	domains = {
		'blocks-world': ['blocks-world-optimal-20', 'blocks-world-optimal-40', 'blocks-world-optimal-60', 'blocks-world-optimal-80',
						 'blocks-world-suboptimal-20', 'blocks-world-suboptimal-40', 'blocks-world-suboptimal-60', 'blocks-world-suboptimal-80'],
		'depots': ['depots-optimal-20', 'depots-optimal-40', 'depots-optimal-60', 'depots-optimal-80',
				   'depots-suboptimal-20', 'depots-suboptimal-40', 'depots-suboptimal-60', 'depots-suboptimal-80'],
		'driverlog': ['driverlog-optimal-20', 'driverlog-optimal-40', 'driverlog-optimal-60', 'driverlog-optimal-80',
					  'driverlog-suboptimal-20', 'driverlog-suboptimal-40', 'driverlog-suboptimal-60', 'driverlog-suboptimal-80'],
		'easy-ipc-grid': ['easy-ipc-grid-optimal-20', 'easy-ipc-grid-optimal-40', 'easy-ipc-grid-optimal-60', 'easy-ipc-grid-optimal-80',
				'easy-ipc-grid-suboptimal-20', 'easy-ipc-grid-suboptimal-40', 'easy-ipc-grid-suboptimal-60', 'easy-ipc-grid-suboptimal-80'],
		'dwr': ['dwr-optimal-20', 'dwr-optimal-40', 'dwr-optimal-60', 'dwr-optimal-80',
				'dwr-suboptimal-20', 'dwr-suboptimal-40', 'dwr-suboptimal-60', 'dwr-suboptimal-80'],				
		'ferry': ['ferry-optimal-20', 'ferry-optimal-40', 'ferry-optimal-60', 'ferry-optimal-80',
				  'ferry-suboptimal-20', 'ferry-suboptimal-40', 'ferry-suboptimal-60', 'ferry-suboptimal-80'],
		'logistics': ['logistics-optimal-20', 'logistics-optimal-40', 'logistics-optimal-60', 'logistics-optimal-80', 
					  'logistics-suboptimal-20', 'logistics-suboptimal-40', 'logistics-suboptimal-60', 'logistics-suboptimal-80'],
		'miconic': ['miconic-optimal-20', 'miconic-optimal-40', 'miconic-optimal-60', 'miconic-optimal-80', 
					'miconic-suboptimal-20', 'miconic-suboptimal-40', 'miconic-suboptimal-60', 'miconic-suboptimal-80'],
		'rovers': ['rovers-optimal-20', 'rovers-optimal-40', 'rovers-optimal-60', 'rovers-optimal-80', 
				  'rovers-suboptimal-20', 'rovers-suboptimal-40', 'rovers-suboptimal-60', 'rovers-suboptimal-80'],
		'satellite': ['satellite-optimal-20', 'satellite-optimal-40', 'satellite-optimal-60', 'satellite-optimal-80',  
					  'satellite-suboptimal-20', 'satellite-suboptimal-40', 'satellite-suboptimal-60', 'satellite-suboptimal-80'],
		'zeno-travel': ['zeno-travel-optimal-20', 'zeno-travel-optimal-40', 'zeno-travel-optimal-60', 'zeno-travel-optimal-80',
						'zeno-travel-suboptimal-20', 'zeno-travel-suboptimal-40', 'zeno-travel-suboptimal-60', 'zeno-travel-suboptimal-80'],
	}

	approaches = [
		'gc-baseline',
		'gc-definite',
		'gc-definite-possible',
		'gc-definite-overlooked',
		'gc-definite-possible-overlooked',
		'gc-possible',
		'gc-possible-overlooked',
		'gc-overlooked',
		'uniqueness-baseline',
		'uniqueness-definite',
		'uniqueness-possible',
		'uniqueness-overlooked',
		'uniqueness-definite-overlooked',
		'uniqueness-definite-possible-overlooked',
		'uniqueness-possible-definite',
		'uniqueness-possible-overlooked'
	]
	
	for domain in domains:
		for d in domains[domain]:
			for ap in approaches:
				print '-> Running Experiments ' + d
				cmdJar = 'java -jar recognizer3.2-incomplete_domains.jar recognition-mini_dataset/' + domain + '/' + d + ' ' + ap
				print cmdJar
				# os.system(cmdJar)
				
if __name__ == '__main__' :
	main()