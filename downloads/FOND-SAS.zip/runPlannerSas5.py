#!/usr/bin/python
import sys
import os
import subprocess

def main() :
	benchmarks = ["data/benchmarks-fond_sas_mynd/"]

	heuristics = ["FF", "HMAX", "LMCUT", "PDBS", "ZERO"]

	strategies = [
				  '"[OLDEST(FF), MIN_H]"',
				  '"[OLDEST(HMAX), MIN_H]"',
				  '"[OLDEST(LMCUT), MIN_H]"',
				  '"[OLDEST(PDBS), MIN_H]"',
				  '"[OLDEST(ZERO), MIN_H]"'
				  ]

	searches = ["LAOSTAR"]

	for path in benchmarks:
		for filename in os.listdir(path):
			for search in searches:
				for h in heuristics:
					for s in strategies:
						if h in s:
							continue
					
						for filename in os.listdir(path):
							if ".sas" in filename and 'domain.pddl' not in filename:
								pddl_p = filename.split('/')
								pddl_p = pddl_p[len(pddl_p)-1]

								output_file =  pddl_p.replace('.sas', '') + '-' + search + '-' + h + '-' + s + '.txt'
								command = 'java -jar myNDPlus0.1.jar -timeout 1200 -search ' + search + ' -heuristic ' + h + ' -strategy ' + s + ' ' + path + filename + ' > ' + output_file
								print command
								print ''
								os.system(command)

if __name__ == '__main__' :
	main()
